﻿using AgriEnergy.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace AgriEnergy.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Farmer> Farmers { get; set; }
        public DbSet<Product> Products { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Seed Employees
            modelBuilder.Entity<Employee>().HasData(
                new Employee { Id = "1", EmployeeId = 1, Name = "John", Surname = "Stones" },
                new Employee { Id = "2", EmployeeId = 2, Name = "Ruben", Surname = "Dias" },
                new Employee { Id = "3", EmployeeId = 3, Name = "Kyle", Surname = "Walker" }
            );

            // Seed Farmers
            modelBuilder.Entity<Farmer>().HasData(
                new Farmer { FarmerId = 1, Name = "Gerald", Surname = "Pique" },
                new Farmer { FarmerId = 2, Name = "Carlos", Surname = "Puyol" },
                new Farmer { FarmerId = 3, Name = "Eric", Surname = "Abidal" }
            );

            // Seed Products
            modelBuilder.Entity<Product>().HasData(
                new Product { ProductId = 1, ProductName = "Banana", Price = 9, Category = "Fruit", Date = DateTime.Now, FarmerId = "2" },
                new Product { ProductId = 2, ProductName = "Milk", Price = 25, Category = "Protein", Date = DateTime.Now, FarmerId ="1" },
                new Product { ProductId = 3, ProductName = "Cabbage", Price = 17, Category = "Vegetable", Date = DateTime.Now, FarmerId = "3" },
                new Product { ProductId = 4, ProductName = "Rye Bread", Price = 75, Category = "Carbohydrates", Date = DateTime.Now, FarmerId = "1" },
                new Product { ProductId = 5, ProductName = "Spanish", Price = 36, Category = "Vegetable", Date = DateTime.Now, FarmerId = "3" }
            );
        }
    }
}
