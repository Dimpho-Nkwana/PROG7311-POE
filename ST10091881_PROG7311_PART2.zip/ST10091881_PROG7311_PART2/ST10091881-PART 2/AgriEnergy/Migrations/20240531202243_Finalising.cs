﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AgriEnergy.Migrations
{
    /// <inheritdoc />
    public partial class Finalising : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
