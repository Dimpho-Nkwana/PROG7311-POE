﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace AgriEnergy.Migrations
{
    /// <inheritdoc />
    public partial class DumbyData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "AspNetUsers",
                columns: new[] { "Id", "AccessFailedCount", "ConcurrencyStamp", "Discriminator", "Email", "EmailConfirmed", "FarmerId", "LockoutEnabled", "LockoutEnd", "Name", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "Surname", "TwoFactorEnabled", "UserName" },
                values: new object[,]
                {
                    { "012f7e41-e2ab-4eb0-93ac-53ea2048cdc5", 0, "433d52b7-d718-44f6-9bab-05426a71bb26", "Farmer", null, false, 2, false, null, "Carlos", null, null, null, null, false, "53f50c09-8dea-4466-9f10-e25d06566527", "Puyol", false, null },
                    { "059ea58e-5819-41c4-b6f2-bc46cb7d6e29", 0, "7042edd6-f6de-4bab-a792-7e27e498f2f4", "Farmer", null, false, 1, false, null, "Gerald", null, null, null, null, false, "59c967a4-c3f2-43d4-ad63-c034835112a4", "Pique", false, null }
                });

            migrationBuilder.InsertData(
                table: "AspNetUsers",
                columns: new[] { "Id", "AccessFailedCount", "ConcurrencyStamp", "Discriminator", "Email", "EmailConfirmed", "EmployeeId", "LockoutEnabled", "LockoutEnd", "Employee_Name", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "Employee_Surname", "TwoFactorEnabled", "UserName" },
                values: new object[,]
                {
                    { "1", 0, "97a8be62-4f00-42f9-b221-8d37f52a385b", "Employee", null, false, 1, false, null, "John", null, null, null, null, false, "6ff4cceb-4c7f-4d3c-8392-c722e9e1c872", "Stones", false, null },
                    { "2", 0, "f848ae14-b503-435e-8929-a6480963bf73", "Employee", null, false, 2, false, null, "Ruben", null, null, null, null, false, "c0753927-17bc-45c2-88b8-e2243313fc87", "Dias", false, null },
                    { "3", 0, "ba739280-7dab-499f-b742-44f942138a13", "Employee", null, false, 3, false, null, "Kyle", null, null, null, null, false, "6171749c-c243-4700-93e7-446cdcb90d6f", "Walker", false, null }
                });

            migrationBuilder.InsertData(
                table: "AspNetUsers",
                columns: new[] { "Id", "AccessFailedCount", "ConcurrencyStamp", "Discriminator", "Email", "EmailConfirmed", "FarmerId", "LockoutEnabled", "LockoutEnd", "Name", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "Surname", "TwoFactorEnabled", "UserName" },
                values: new object[] { "80ecaab9-fdd0-44bb-9fe3-6cab7f95791d", 0, "6a7ba9a7-b059-4d1f-96c4-be34566abb8e", "Farmer", null, false, 3, false, null, "Eric", null, null, null, null, false, "e3f42db9-ab56-4bac-bce3-25534e413275", "Abidal", false, null });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "ProductId", "Category", "Date", "FarmerId", "Price", "ProductName" },
                values: new object[,]
                {
                    { 1, "Fruit", new DateTime(2024, 5, 31, 23, 25, 12, 726, DateTimeKind.Local).AddTicks(3806), "2", 9, "Banana" },
                    { 2, "Protein", new DateTime(2024, 5, 31, 23, 25, 12, 726, DateTimeKind.Local).AddTicks(3818), "1", 25, "Milk" },
                    { 3, "Vegetable", new DateTime(2024, 5, 31, 23, 25, 12, 726, DateTimeKind.Local).AddTicks(3820), "3", 17, "Cabbage" },
                    { 4, "Carbohydrates", new DateTime(2024, 5, 31, 23, 25, 12, 726, DateTimeKind.Local).AddTicks(3821), "1", 75, "Rye Bread" },
                    { 5, "Vegetable", new DateTime(2024, 5, 31, 23, 25, 12, 726, DateTimeKind.Local).AddTicks(3822), "3", 36, "Spanish" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "012f7e41-e2ab-4eb0-93ac-53ea2048cdc5");

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "059ea58e-5819-41c4-b6f2-bc46cb7d6e29");

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "80ecaab9-fdd0-44bb-9fe3-6cab7f95791d");

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "1");

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "2");

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "3");
        }
    }
}
