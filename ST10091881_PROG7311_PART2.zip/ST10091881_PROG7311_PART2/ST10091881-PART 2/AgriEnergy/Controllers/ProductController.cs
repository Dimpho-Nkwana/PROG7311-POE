﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AgriEnergy.Data;
using AgriEnergy.Models;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace AgriEnergy.Controllers
{
    [Authorize]
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public ProductController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            var user = await _userManager.GetUserAsync(User);
            if (User.IsInRole("Employee"))
            {
                return View(await _context.Products.Include(p => p.Farmer).ToListAsync());
            }
            else if (User.IsInRole("Farmer"))
            {
                var products = await _context.Products
                    .Where(p => p.FarmerId == user.Id)
                    .Include(p => p.Farmer)
                    .ToListAsync();
                return View(products);
            }
            return Unauthorized();
        }

        public async Task<IActionResult> FarmerProducts(string farmerId, DateTime? startDate, DateTime? endDate, string category)
        {
            if (farmerId == null)
            {
                return NotFound();
            }

            var productsQuery = _context.Products.AsQueryable();

            if (!string.IsNullOrEmpty(category))
            {
                productsQuery = productsQuery.Where(p => p.Category == category);
            }

            if (startDate.HasValue)
            {
                productsQuery = productsQuery.Where(p => p.Date >= startDate.Value);
            }

            if (endDate.HasValue)
            {
                productsQuery = productsQuery.Where(p => p.Date <= endDate.Value);
            }

            var products = await productsQuery
                .Where(p => p.FarmerId == farmerId)
                .Include(p => p.Farmer)
                .ToListAsync();

            if (!products.Any())
            {
                return NotFound();
            }

            ViewBag.FarmerName = products.FirstOrDefault()?.Farmer?.Name;
            ViewBag.Category = new SelectList(_context.Products.Select(p => p.Category).Distinct());

            return View(products);
        }



        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products
                .Include(p => p.Farmer)
                .FirstOrDefaultAsync(m => m.ProductId == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        public IActionResult Create()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProductName,Price,Category,Date")] Product product)
        {
            var user = await _userManager.GetUserAsync(User);
            await Console.Out.WriteLineAsync("create");
            if (ModelState.IsValid)
            {
                await Console.Out.WriteLineAsync("fields");
                product.FarmerId = user.Id;
                await Console.Out.WriteLineAsync("Saving");
                _context.Add(product);
                await Console.Out.WriteLineAsync("Saving");
                await _context.SaveChangesAsync();
                await Console.Out.WriteLineAsync("SAVED");
                return RedirectToAction(nameof(Index));
            }
            return View(product);
        }


        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ProductId,ProductName,Price,Category,Date")] Product product)
        {
            if (id != product.ProductId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(product);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductExists(product.ProductId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(product);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products
                .Include(p => p.Farmer)
                .FirstOrDefaultAsync(m => m.ProductId == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product != null)
            {
                _context.Products.Remove(product);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        private bool ProductExists(int id)
        {
            return _context.Products.Any(e => e.ProductId == id);
        }
    }
}
