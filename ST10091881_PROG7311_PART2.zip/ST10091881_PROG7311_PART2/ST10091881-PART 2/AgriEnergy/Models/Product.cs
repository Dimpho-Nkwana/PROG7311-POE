﻿namespace AgriEnergy.Models
{
    public class Product
    {
        public int ProductId { get; set; }

        public string ProductName { get; set; }

        public int Price { get; set; }

        public string Category { get; set; }

        public DateTime Date { get; set; }

        public string FarmerId { get; set; }
        public Farmer Farmer { get; set; }

    }
}
