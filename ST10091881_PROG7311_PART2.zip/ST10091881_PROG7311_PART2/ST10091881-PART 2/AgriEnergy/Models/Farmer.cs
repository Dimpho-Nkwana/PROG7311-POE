﻿using Microsoft.AspNetCore.Identity;

namespace AgriEnergy.Models
{
    // Code inspired by the following YouTube video:
    // Title:ASP.NET Identity - User Registration, Login and Log-out
    // URL:https://www.youtube.com/watch?v=ghzvSROMo_M
    // Channel: Digital TechJoint
    // Published on: 26 October 2022
    public class Farmer : IdentityUser
    {
        public int FarmerId { get; set; }

        public string Name { get; set; }

        public string Surname { get; set; }
    }
}
