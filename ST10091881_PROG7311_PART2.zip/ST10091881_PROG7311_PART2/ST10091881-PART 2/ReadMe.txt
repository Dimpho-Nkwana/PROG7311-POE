AgriEnergy ReadMe

## Table of Contents

- Introduction 
- Features
- Installation
- Technologies Used
- License (#license)

## Introduction

This project is was made as a prototype designed to streamline and improve the efficiency of the farming operations through user-friendly web-based platform. The system incorporates some components and technologies toe give a solution to managing employees, farmers and their products

## Features

###Farmer 
- Create/Add Farmer
- View products added by farmer 
- View Farmer details  

###Employee
- Create/Add Employee
- View Employee
- View Farmers 
- View Farmer's products

###Products 
- Create/Add Products 
- View Products
- Filter Products


###Additional 
- Login and Registration 
- Database storage 
- Role Based access

## Installation

make sure you have Microsoft Visual Studios and SQL Server Management Studio on computer 

1. Clone Repository
https://github.com/IIEWFL/prog7311-part-2-ST10225560.git

2. Open unzip zipped file

3. Open File named AgriEnergy and open solution in Visual studio 

4. Take the sql bacpac file and run the Query to create the database on SSMS

5. On Visual Studio run solution  

##Technologies Used

IDE: Microsoft Visual studios 
Database: SSMS

##License

MIT License 