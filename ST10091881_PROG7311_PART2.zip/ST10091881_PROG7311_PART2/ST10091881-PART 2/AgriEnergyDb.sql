USE master
IF EXISTS (SELECT * FROM Sys.databases WHERE name = 'AgriEnergy')
DROP DATABASE AgriEnergyDB
CREATE DATABASE AgriEnergyDB
USE AgriEnergyDB

select* from Products
